"""
    Alunos:
        nome: Danilo de Moraes Costa ()
        nome: Lucas de Almeida Carotta ()
        nome: Isadora ()

    Trabalho:
        Implementação do trabalho de Base de Dados: Tóquio Olimpíadas 2020
"""

from fpdf import FPDF
import tkinter as tk
from tkinter import font as tkfont
from BD.SGBD import Database

# ------------------------------------ SGBD ---------------------------------- #

class baseDeDados:
    def __init__(self, *args, **kwargs):
        self.DB = Database('./BD/olimpiadas.db')

    def gerar_relatorio(self):
        print("Nothing")

    def fechar_conexao(self):
        self.DB.close()

# --------------------------------- INTERFACE -------------------------------- #

class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Selecione a opção desejada", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        button1 = tk.Button(self, text="Gerar relatório", command=lambda: controller.show_frame("PageOne"))
        button2 = tk.Button(self, text="Rodar scripts", command=lambda: controller.show_frame("PageTwo"))
        button3 = tk.Button(self, text="Fechar", command=lambda: controller.destroy())
        button1.pack()
        button2.pack()
        button3.pack()

class PageOne(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Gerar relatório", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)
        text = tk.Label(self, text="Selecione o tipo de relatório que deseja.")
        text.pack(side="top", fill="x")
        atletas = tk.Button(self, text="Listagem por atletas", command=print('nada'))
        medico = tk.Button(self, text="Listagem por médicos", command=print('nada'))
        treinos = tk.Button(self, text="Listagem por treinos", command=print('nada'))
        treinador = tk.Button(self, text="Listagem por treinador", command=print('nada'))
        menu = tk.Button(self, text="Voltar", command=lambda: controller.show_frame("StartPage"))
        atletas.pack()
        medico.pack()
        treinos.pack()
        treinador.pack()
        menu.pack()

class PageTwo(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="Rodar scripts", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)
        text = tk.Label(self, text="Selecione o tipo de scprit que deseja rodar.")
        text.pack(side="top", fill="x")
        menu = tk.Button(self, text="Voltar", command=lambda: controller.show_frame("StartPage"))
        menu.pack()

# ---------------------------------- MAIN ------------------------------------ #

class olimpiadas(tk.Tk):
    def __init__(self, *args, **kwargs):
        self.base = baseDeDados()
        tk.Tk.__init__(self, *args, **kwargs)
        self.title_font = tkfont.Font(family="Opções", size=18, weight="bold", slant="italic")

        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, PageOne, PageTwo):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("StartPage")
    def show_frame(self, page_name):
        '''Motre a tela na janela da interface selcionada'''
        frame = self.frames[page_name]
        frame.tkraise()

app = olimpiadas()
app.mainloop()

# ----------------------------------- EOF ------------------------------------ #
